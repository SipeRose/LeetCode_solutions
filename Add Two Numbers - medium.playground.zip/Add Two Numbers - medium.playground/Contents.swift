import UIKit

//Definition for singly-linked list.
public class ListNode {
     public var val: Int
     public var next: ListNode?
     public init() { self.val = 0; self.next = nil; }
     public init(_ val: Int) { self.val = val; self.next = nil; }
     public init(_ val: Int, _ next: ListNode?) { self.val = val; self.next = next; }
 }

class Solution {
    func addTwoNumbers(_ l1: ListNode?, _ l2: ListNode?) -> ListNode? {

        var mas1 = [Int]()
        var mas2 = [Int]()
        var l11 = l1
        var l22 = l2

        while l11?.val != nil {
            mas1.append(l11!.val)
            l11 = l11?.next
        }

        while l22?.val != nil {
            mas2.append(l22!.val)
            l22 = l22?.next
        }

        if mas1.count > mas2.count {
            for _ in (mas2.count..<mas1.count) {
                mas2.append(0)
            }
        } else if mas2.count > mas1.count {
            for _ in (mas1.count..<mas2.count) {
                mas1.append(0)
            }
        }

        var mas3 = [Int]()

        for (item1, item2) in zip(mas1, mas2){
            mas3.append(item1 + item2)
        }

        for index in (0 ..< (mas3.count - 1)) {
            if mas3[index] > 9 {
                mas3[index] = mas3[index] % 10
                mas3[index + 1] = mas3[index + 1] + 1
            }
        }

        if mas3[mas3.count - 1] > 9 {
            mas3[mas3.count - 1] = mas3[mas3.count - 1] % 10
            mas3.append(1)
        }

        mas3.reverse()

        var l3: ListNode? = nil

        for item in mas3 {
            l3 = ListNode(item, l3)
        }
        return l3
    }

}

//var l1:  ListNode?
//let l2 = ListNode(2, ListNode(4, ListNode(3)))
//
//let a = [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1]
//
//for item in a {
//    l1 = ListNode(item, l1)
//}
//
//print(Solution().addTwoNumbers(l1, l2)!.val)
