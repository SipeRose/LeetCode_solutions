import UIKit

class Solution {
    func reverse(_ x: Int) -> Int {
        
        let isNegative = { return x < 0 }
        let str = String(x)
        var revStr = String(str.reversed())
        
        if revStr.contains("-") {
            revStr.removeLast()
        }
 
        guard let _ = Int32(exactly: Int(revStr)!) else { return 0 }
        
        guard let _ = Int(revStr) else { return 0 }
        
        var result1 = Int(revStr)!
        
        if isNegative() {
            result1 = -result1
        }
        
        
        return result1
    }
}


//let x = 1534236469
//print(Solution().reverse(x))
