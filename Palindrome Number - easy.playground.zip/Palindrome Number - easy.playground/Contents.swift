import UIKit

class Solution {
    func isPalindrome(_ x: Int) -> Bool {
        let str = String(x)
        var mas1 = [Character]()
        var mas2 = [Character]()
        
        for letter in str {
            mas1.append(letter)
            mas2.append(letter)
        }
        
        mas2.reverse()
        
        return mas1 == mas2
    }
}
