import UIKit

class Solution {
    func lengthOfLongestSubstring(_ s: String) -> Int {
        
        var letterMas = [Character]()
        var length = 0
        
        for letter in s {
                
                if letterMas.count > length {
                    length = letterMas.count
                }
                letterMas.append(letter)
                if letterMas.firstIndex(of: letter) != (letterMas.count - 1) {
                    while letterMas.firstIndex(of: letter) != (letterMas.count - 1) {
                        letterMas.remove(at: 0)
                    }
                }
        }
        
        if letterMas.count > length {
            length = letterMas.count
        }
        
        return length
    }
}

//let s = "pwwkew"
//
//print(Solution().lengthOfLongestSubstring(s))
