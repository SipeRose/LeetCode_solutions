import UIKit

class Solution {

    func twoSum(_ nums: [Int], _ target: Int) -> [Int] {
        var massive: [Int] = []
        for index1 in (0 ..< (nums.count - 1)) {
            for index2 in ((index1 + 1) ..< nums.count) {
                var summa = nums[index1] + nums[index2]
                if summa == target {
                    massive.append(index1)
                    massive.append(index2)
                    break
                }
            }
        }
        return massive
    }
}

//let nums = [3,4]
//let target = 6
//print(Solution().twoSum(nums, target))
